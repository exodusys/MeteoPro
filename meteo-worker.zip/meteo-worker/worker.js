// Météo Pro — proxy MET Norway sur Cloudflare Workers (cache partagé + User-Agent identifiant).
// Le navigateur appelle  https://<ton-worker>/locationforecast/2.0/compact?lat=..&lon=..  (mêmes chemins que MET).
const BASE = "https://api.met.no/weatherapi/";
const ROUTES = {
  "locationforecast/2.0/compact":  ["lat", "lon", "altitude"],
  "locationforecast/2.0/complete": ["lat", "lon", "altitude"],
  "sunrise/3.0/sun":               ["lat", "lon", "date", "offset"],
};
const COORD_DEC = 2;            // 2 décimales ≈ 1,1 km : partage le cache entre utilisateurs proches (MET accepte ≤ 4)
const STALE_EXTRA = 6 * 3600e3; // on garde l'entrée 6 h de plus pour servir une version périmée si MET est en panne
const inflight = new Map();     // coalescence des requêtes identiques dans un même isolat

/* Durées minimales MET (Locationforecast, conditions du 5 nov. 2026) : 30 min région nordique, 3 h ailleurs. */
function nordic(lat, lon) {
  if (lon < 4.5 || lon > 31.3 || lat < 55.3 || lat > 71.5) return false;
  if (lat < 59.6 && lon > 20.5) return false;
  if (lat < 61 && lon > 26.5) return false;
  return true;
}
function minTtl(route, lat, lon) {
  if (!route.startsWith("locationforecast")) return 3600e3;
  return nordic(lat, lon) ? 1800e3 : 3 * 3600e3;
}
function normalize(route, q) {
  const o = new URLSearchParams();
  for (const k of ROUTES[route]) {
    let v = q.get(k); if (v == null) continue;
    if (k === "lat" || k === "lon") { const n = +v; if (!isFinite(n)) return null; v = n.toFixed(COORD_DEC); }
    else if (k === "altitude") { const n = Math.round(+v / 10) * 10; if (!isFinite(n)) return null; v = String(n); }
    else if (k === "date") { if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return null; }
    else if (k === "offset") { if (!/^[+-]\d{2}:\d{2}$/.test(v)) return null; }
    o.set(k, v);
  }
  if (!o.has("lat") || !o.has("lon")) return null;
  if (Math.abs(+o.get("lat")) > 90 || Math.abs(+o.get("lon")) > 180) return null;
  return o;
}
function corsHeaders(origin, env) {
  const h = new Headers();
  const allow = (env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean);
  if (origin && (allow.includes("*") || allow.includes(origin))) {
    h.set("Access-Control-Allow-Origin", origin);
    h.set("Vary", "Origin");
  }
  h.set("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
  h.set("Access-Control-Allow-Headers", "Accept, If-Modified-Since");
  h.set("Access-Control-Expose-Headers", "Expires, Last-Modified, X-Cache");
  h.set("Access-Control-Max-Age", "86400");
  return h;
}
const json = (obj, status, extra) => new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json", ...extra } });

async function fromUpstream(route, o, old, env) {
  if (!env.MET_UA) throw Object.assign(new Error("MET_UA manquant"), { status: 500 });
  const h = { "User-Agent": env.MET_UA, "Accept": "application/json" };
  if (old && old.lm) h["If-Modified-Since"] = old.lm;
  const r = await fetch(BASE + route + "?" + o.toString(), { headers: h });
  const now = Date.now();
  const lat = +o.get("lat"), lon = +o.get("lon");
  const ttl = () => {
    const e = Date.parse(r.headers.get("expires") || "");
    return Math.max(isFinite(e) ? e - now : 0, minTtl(route, lat, lon)) + Math.random() * 2 * 60e3;
  };
  if (r.status === 304 && old) return { ...old, exp: now + ttl(), fresh: true };
  if (!r.ok) throw Object.assign(new Error("MET " + r.status), { status: r.status });
  return { body: await r.text(), ctype: r.headers.get("content-type") || "application/json", lm: r.headers.get("last-modified") || "", exp: now + ttl(), fresh: true };
}

async function load(route, o, env, ctx) {
  const key = new Request("https://cache.meteopro.invalid/" + route + "?" + o.toString());
  const cache = caches.default, now = Date.now();
  let old = null;
  const hit = await cache.match(key);
  if (hit) {
    old = { body: await hit.text(), ctype: hit.headers.get("Content-Type"), lm: hit.headers.get("X-Lm") || "", exp: +hit.headers.get("X-Exp") };
    if (old.exp > now) return { e: old, st: "HIT" };
  }
  const k = key.url;
  if (inflight.has(k)) return { e: await inflight.get(k), st: "COALESCED" };
  const p = (async () => {
    try {
      const e = await fromUpstream(route, o, old, env);
      const res = new Response(e.body, { headers: {
        "Content-Type": e.ctype, "X-Lm": e.lm, "X-Exp": String(e.exp),
        "Cache-Control": "public, max-age=" + Math.floor((e.exp - Date.now() + STALE_EXTRA) / 1000) } });
      ctx.waitUntil(cache.put(key, res));
      return e;
    } catch (err) {
      if (old && Date.now() - old.exp < STALE_EXTRA) return { ...old, exp: Date.now() + 60e3, stale: true };   // MET en panne : version périmée
      throw err;
    }
  })().finally(() => inflight.delete(k));
  inflight.set(k, p);
  return { e: await p, st: old ? "REVALIDATED" : "MISS" };
}

export default {
  async fetch(req, env, ctx) {
    const origin = req.headers.get("Origin");
    const cors = corsHeaders(origin, env);
    const corsOK = !origin || cors.has("Access-Control-Allow-Origin");
    if (req.method === "OPTIONS") return new Response(null, { status: corsOK ? 204 : 403, headers: cors });
    if (req.method !== "GET" && req.method !== "HEAD") return json({ error: "method" }, 405, Object.fromEntries(cors));
    if (!corsOK) return json({ error: "origin non autorisée" }, 403, {});
    const url = new URL(req.url);
    const route = url.pathname.replace(/^\/+/, "");
    if (route === "") return new Response("Météo Pro proxy · données : MET Norway (CC BY 4.0)", { headers: cors });
    if (!ROUTES[route]) return json({ error: "route inconnue" }, 404, Object.fromEntries(cors));
    const o = normalize(route, url.searchParams);
    if (!o) return json({ error: "paramètres invalides" }, 400, Object.fromEntries(cors));
    try {
      const { e, st } = await load(route, o, env, ctx);
      const h = new Headers(cors);
      h.set("Expires", new Date(e.exp).toUTCString());
      h.set("Cache-Control", "public, max-age=" + Math.max(0, Math.floor((e.exp - Date.now()) / 1000)));
      h.set("X-Cache", st + (e.stale ? "-STALE" : ""));
      if (e.lm) h.set("Last-Modified", e.lm);
      const ims = Date.parse(req.headers.get("If-Modified-Since") || "");
      if (e.lm && isFinite(ims) && Date.parse(e.lm) <= ims) return new Response(null, { status: 304, headers: h });
      h.set("Content-Type", e.ctype || "application/json");
      return new Response(req.method === "HEAD" ? null : e.body, { status: 200, headers: h });
    } catch (err) {
      const s = err.status === 429 || err.status === 403 ? 503 : 502;
      return json({ error: String(err.message || err) }, s, { ...Object.fromEntries(cors), "Retry-After": "300" });
    }
  },
};
