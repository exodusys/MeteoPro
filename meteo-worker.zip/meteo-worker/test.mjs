// Test local sans Cloudflare : simule caches.default et le fetch vers MET.
import worker from "./worker.js";
const store = new Map();
globalThis.caches = { default: {
  async match(req){ const r = store.get(req.url); return r ? r.clone() : undefined },
  async put(req,res){ store.set(req.url, res) } } };
let calls = [], mode = "ok", lm = "Thu, 26 Nov 2026 08:00:00 GMT";
globalThis.fetch = async (url, init) => {
  calls.push({ url, h: init.headers });
  if (mode === "down") return new Response("x", { status: 503 });
  if (mode === "304" && init.headers["If-Modified-Since"]) return new Response(null, { status: 304, headers: { Expires: new Date(Date.now()+60e3).toUTCString() } });
  return new Response(JSON.stringify({ properties: { timeseries: [] }, url }), { headers: { "content-type":"application/json", Expires: new Date(Date.now()+60e3).toUTCString(), "Last-Modified": lm } });
};
const env = { MET_UA: "MeteoPro/1.0 exodusys@gmail.com", ALLOWED_ORIGINS: "https://exodusys.github.io" };
const ctx = { waitUntil: p => p };
const O = "https://exodusys.github.io";
const get = (path, hdr = {}) => worker.fetch(new Request("https://w.example/" + path, { headers: { Origin: O, ...hdr } }), env, ctx);
const ok = (c, m) => { console.log((c ? "OK   " : "FAIL ") + m); if (!c) process.exitCode = 1 };

let r = await get("locationforecast/2.0/compact?lat=47.3769&lon=8.5417");
ok(r.status === 200 && r.headers.get("X-Cache") === "MISS", "1er appel = MISS " + r.status);
ok(calls.length === 1 && calls[0].h["User-Agent"] === env.MET_UA, "User-Agent envoyé à MET");
ok(calls[0].url.includes("lat=47.38&lon=8.54"), "coordonnées arrondies : " + calls[0].url.split("?")[1]);
ok(r.headers.get("Access-Control-Allow-Origin") === O && r.headers.get("Access-Control-Expose-Headers").includes("Expires"), "CORS + Expires exposé");
const dMin = (Date.parse(r.headers.get("Expires")) - Date.now()) / 60e3;
ok(dMin > 179 && dMin < 184, "Zurich : TTL minimum 3 h (" + dMin.toFixed(0) + " min) malgré Expires à 1 min");
r = await get("locationforecast/2.0/compact?lat=47.3801&lon=8.5399");
ok(r.headers.get("X-Cache") === "HIT" && calls.length === 1, "position voisine = HIT, aucun appel MET");
r = await get("locationforecast/2.0/compact?lat=47.38&lon=8.54", { "If-Modified-Since": lm });
ok(r.status === 304, "If-Modified-Since → 304");
r = await get("locationforecast/2.0/compact?lat=59.91&lon=10.75");
const dN = (Date.parse(r.headers.get("Expires")) - Date.now()) / 60e3;
ok(dN > 29 && dN < 34, "Oslo : TTL minimum 30 min (" + dN.toFixed(0) + " min)");
r = await get("sunrise/3.0/sun?lat=47.38&lon=8.54&date=2026-11-26&offset=%2B00:00");
ok(r.status === 200, "sunrise OK");
r = await get("locationforecast/2.0/compact?lat=abc&lon=1");  ok(r.status === 400, "paramètres invalides → 400");
r = await get("autre/chose?lat=1&lon=1");                      ok(r.status === 404, "route inconnue → 404");
r = await worker.fetch(new Request("https://w.example/locationforecast/2.0/compact?lat=1&lon=1", { headers: { Origin: "https://pirate.example" } }), env, ctx);
ok(r.status === 403, "origine non autorisée → 403");
r = await worker.fetch(new Request("https://w.example/x", { method: "OPTIONS", headers: { Origin: O } }), env, ctx);
ok(r.status === 204 && r.headers.get("Access-Control-Allow-Headers").includes("If-Modified-Since"), "préflight OK");
// expiration → revalidation 304 puis panne MET → version périmée
for (const [k, v] of store) { const h = new Headers(v.headers); h.set("X-Exp", String(Date.now() - 1000)); store.set(k, new Response(null) && new Response(await v.clone().text(), { headers: h })) }
mode = "304"; const n = calls.length;
r = await get("locationforecast/2.0/compact?lat=47.38&lon=8.54");
ok(r.headers.get("X-Cache") === "REVALIDATED" && calls.length === n + 1 && calls[n].h["If-Modified-Since"] === lm, "expiré → revalidation avec If-Modified-Since");
for (const [k, v] of store) { const h = new Headers(v.headers); h.set("X-Exp", String(Date.now() - 1000)); store.set(k, new Response(await v.clone().text(), { headers: h })) }
mode = "down";
r = await get("locationforecast/2.0/compact?lat=47.38&lon=8.54");
ok(r.status === 200 && r.headers.get("X-Cache").includes("STALE"), "MET en panne → réponse périmée servie");
r = await get("locationforecast/2.0/compact?lat=10&lon=10");
ok(r.status === 502 || r.status === 503, "MET en panne sans cache → " + r.status);
