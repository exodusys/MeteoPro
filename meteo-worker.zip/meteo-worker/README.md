# Météo Pro — proxy Cloudflare Worker

Proxy MET Norway avec cache partagé, `User-Agent` identifiant et coordonnées arrondies (2 décimales).
Respecte les minimums MET : 30 min (région nordique) / 3 h (reste du monde), `Expires`, `If-Modified-Since`.

## Déployer (sans rien installer, depuis le navigateur)
1. Crée un compte gratuit sur https://dash.cloudflare.com
2. **Workers & Pages → Create → Create Worker**, nom : `meteopro-proxy`, puis **Deploy**.
3. **Edit code** : remplace tout par le contenu de `worker.js`, puis **Deploy**.
4. **Settings → Variables and Secrets** → ajoute (type *Text*) :
   - `MET_UA` = `MeteoPro/1.0 exodusys@gmail.com`
   - `ALLOWED_ORIGINS` = `https://exodusys.github.io`
5. Note l'adresse du Worker (ex. `https://meteopro-proxy.<compte>.workers.dev`).

## Déployer avec la ligne de commande (alternative)
```
npm i -g wrangler
wrangler login
wrangler deploy        # utilise wrangler.toml (MET_UA et ALLOWED_ORIGINS y sont déjà)
```

## Brancher l'appli
Dans `meteo-pro-metno.html`, remplace :
```js
const PROXY="";
```
par (avec **la barre finale**) :
```js
const PROXY="https://meteopro-proxy.<compte>.workers.dev/";
```
Si le Worker est en panne (erreur 5xx/429 ou réseau), l'appli retombe automatiquement sur MET Norway en direct.

## Vérifier
- `https://<worker>/` affiche « Météo Pro proxy ».
- `https://<worker>/locationforecast/2.0/compact?lat=47.37&lon=8.54` renvoie le JSON (en-tête `X-Cache: MISS`, puis `HIT`).
  Sans en-tête `Origin` (navigateur direct) la requête est acceptée ; depuis un autre site, elle est refusée (403).
- Test local du code : `node test.mjs` (simule le cache et MET).

## Limites à connaître
- Le cache de Cloudflare est **par centre de données** : un utilisateur à Zurich et un autre à Paris peuvent chacun déclencher un appel MET. Le nombre d'appels reste faible (positions × centres × 8 par jour).
- Plan gratuit : 100 000 requêtes/jour. Au-delà, plan payant à 5 $/mois.
- Le compteur « Requêtes envoyées à MET Norway » des paramètres compte désormais les requêtes vers le proxy.
